// Fonction pour ouvrir/fermer le menu burger
function toggleMenu() {
    document.body.classList.toggle('open');
}

document.addEventListener('DOMContentLoaded', function() {
    // Sélectionne le bouton du burger
    const burgerButton = document.querySelector('.burger');

    // Ajoute un écouteur d'événement pour l'ouverture/fermeture du menu
    if (burgerButton) {
        burgerButton.addEventListener('click', toggleMenu);
    } else {
        console.error('Bouton du menu burger non trouvé.');
    }
});