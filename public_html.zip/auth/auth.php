<?php
// Inclure la connexion à la base de données
include('../db/connection.php');

// Vérifier si le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    // Vérifier si l'email existe dans la base de données
    $query = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Générer un token unique pour la réinitialisation
        $token = bin2hex(random_bytes(50));
        $user = $result->fetch_assoc();
        $user_id = $user['id'];

        // Enregistrer le token dans la base de données
        $query = "UPDATE users SET reset_token = ?, reset_token_expiry = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('si', $token, $user_id);
        $stmt->execute();

        // Envoyer l'email de réinitialisation (à configurer selon ton serveur)
        $reset_link = "http://yourdomain.com/auth/reset_password.php?token=$token";
        $subject = "Réinitialisation de votre mot de passe";
        $message = "Cliquez sur le lien suivant pour réinitialiser votre mot de passe : $reset_link";
        $headers = "From: no-reply@yourdomain.com";

        mail($email, $subject, $message, $headers);

        echo "Un email de réinitialisation de mot de passe a été envoyé à votre adresse.";
    } else {
        echo "Aucun compte trouvé avec cet email.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation du mot de passe</title>
    <link rel="stylesheet" href="../auth/style.css">
</head>
<body>
    <h1>Réinitialisation du mot de passe</h1>

    <form action="reset_password.php" method="POST">
        <label for="email">Votre adresse email :</label>
        <input type="email" id="email" name="email" required><br>
        <input type="submit" value="Envoyer la demande">
    </form>
</body>
</html>

<?php
// Fermer la connexion à la base de données
$conn->close();
?>
