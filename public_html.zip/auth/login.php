<?php
include realpath(dirname(__FILE__) . '/../db/connection.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sécurisation des entrées utilisateur
    $email = trim($_POST['email']);
    $password = md5(trim($_POST['password']));

    // Vérification de la connexion à la base de données
    if ($conn->connect_error) {
        die("Échec de connexion à la base de données : " . $conn->connect_error);
    }

    // Préparation de la requête SQL
    $sql = "SELECT * FROM users WHERE email = ? AND password = ? AND status = 'active'";
    $stmt = $conn->prepare($sql);
    
    if ($stmt) {
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Si les identifiants sont corrects
            $user = $result->fetch_assoc();
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];

            // Redirection en fonction du rôle
            if ($user['role'] == 'admin') {
                header('Location: ../backoffice/index.php');
                exit();
            } elseif ($user['role'] == 'organization') {
                header('Location: ../organizations/index.php');
                exit();
            } else {
                header('Location: ../students/index.php');
                exit();
            }
        } else {
            echo "Identifiants incorrects ou compte inactif.";
        }
    } else {
        echo "Erreur de requête SQL : " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STAGES HUB - Connexion</title>
    <link rel="stylesheet" href="../auth/style.css">
</head>
<body>
    <div class="container">
        <header class="header">
            <button class="close-button">✕</button>
            <h1 class="logo">STAGES HUB</h1>
        </header>

        <div class="content">
            <h1>Connexion</h1>

            <!-- Formulaire de connexion par email -->
            <div class="email-log-in">
                <input type="email" id="email" placeholder=" " required>
                <label for="email">Adresse e-mail</label>
            </div>

            <div class="action-buttons">
                <button class="primary-button">Connexion</button>

                <div class="divider">
                    <p>ou</p>
                </div>

                <button class="secondary-button sign-in-button">
                    <object data="path/to/icon.svg" type="image/svg+xml"></object>
                    Connexion avec Google
                </button>
            </div>

            <div class="sign-up">
                <p>Pas encore de compte ? <a href="/auth/register.php">S'inscrire</a></p>
            </div>
        </div>
    </div>
</body>
</html>