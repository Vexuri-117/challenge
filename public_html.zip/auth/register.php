<?php
include '../db/connection.php';

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Si le rôle sélectionné est "enseignant", on attribue également le rôle "admin"
    if ($role == 'teacher') {
        $role = 'admin'; // L'enseignant aura un rôle admin automatiquement
    }

    // Appel à la fonction de création d'utilisateur
    if (createUser($username, $email, $password, $role)) {
        echo "Votre compte a été créé. Un administrateur doit valider votre compte.";

        // Redirection vers l'interface administrateur une fois validé
        if ($role == 'admin') {
            // On attend que l'administrateur valide le compte
            // Après validation, l'utilisateur est automatiquement redirigé vers l'interface admin

            // Simuler la validation du compte (par exemple, cette condition se vérifie une fois le compte validé)
            // Ici on suppose que la fonction isAccountValidated() retourne si le compte a été validé
            if (isAccountValidated($username)) {
                // Reconnexion automatique après validation
                $_SESSION['username'] = $username;
                $_SESSION['role'] = 'admin';

                // Redirection vers l'interface admin
                header('Location: /admin/dashboard.php');
                exit;
            }
        }
    } else {
        echo "Erreur lors de la création du compte.";
    }
}

// Fonction fictive pour vérifier si un compte a été validé par un admin
function isAccountValidated($username) {
    // Vérifier si le compte est validé dans la base de données
    // Retourne true si le compte est validé, false sinon
    return true; // Supposons que le compte est validé pour cet exemple
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../auth/style.css">
    <title>Inscription - STAGES HUB</title>
</head>
<body>
    <div class="container">
        <header class="header">
            <h1 class="logo">STAGES HUB</h1>
        </header>

        <div class="content">
            <h2>Inscription</h2>
            <form action="register.php" method="POST">
                <div class="input-group">
                    <label for="username">Nom d'utilisateur :</label>
                    <input type="text" name="username" id="username" required>
                </div>

                <div class="input-group">
                    <label for="email">Email :</label>
                    <input type="email" name="email" id="email" required>
                </div>

                <div class="input-group">
                    <label for="password">Mot de passe :</label>
                    <input type="password" name="password" id="password" required>
                </div>

                <div class="input-group">
                    <label for="role">Rôle :</label>
                    <select name="role" id="role" required>
                        <option value="student">Étudiant</option>
                        <option value="organization">Organisation</option>
                        <option value="teacher">Enseignant</option>
                    </select>
                </div>

                <button type="submit" class="primary-button">S'inscrire</button>
            </form>

            <div class="sign-in-link">
                <p>Vous avez déjà un compte ? <a href="/auth/login.php">Se connecter</a></p>
            </div>
        </div>
    </div>
</body>
</html>
