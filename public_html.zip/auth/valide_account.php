<?php
// Inclure la connexion à la base de données
include('../db/connection.php');

// Vérifier si l'utilisateur est administrateur (à implémenter selon le système d'authentification)
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    echo "Accès refusé. Vous n'êtes pas administrateur.";
    exit;
}

// Récupérer tous les comptes en attente de validation
$query = "SELECT id, email, role, status FROM users WHERE status = 'pending'";
$result = $conn->query($query);

// Validation d'un compte utilisateur
if (isset($_GET['action']) && $_GET['action'] === 'validate' && isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Mettre à jour le statut de l'utilisateur en "validé"
    $query = "UPDATE users SET status = 'active' WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id);

    if ($stmt->execute()) {
        echo "Le compte a été validé avec succès.";
    } else {
        echo "Erreur lors de la validation du compte.";
    }
}

// Désactivation d'un compte utilisateur (optionnel)
if (isset($_GET['action']) && $_GET['action'] === 'deactivate' && isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];

    // Mettre à jour le statut de l'utilisateur en "inactif"
    $query = "UPDATE users SET status = 'inactive' WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id);

    if ($stmt->execute()) {
        echo "Le compte a été désactivé.";
    } else {
        echo "Erreur lors de la désactivation du compte.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Validation des comptes utilisateurs</title>
    <link rel="stylesheet" href="../auth/style.css">
</head>
<body>
    <h1>Validation des comptes utilisateurs</h1>

    <div class="accounts-list">
        <?php if ($result->num_rows > 0): ?>
            <ul>
                <?php while ($user = $result->fetch_assoc()): ?>
                    <li>
                        <p>Email : <?= $user['email']; ?></p>
                        <p>Rôle : <?= $user['role']; ?></p>
                        <p>Statut : <?= $user['status']; ?></p>
                        <a href="validate_account.php?action=validate&user_id=<?= $user['id']; ?>">Valider</a>
                        <a href="validate_account.php?action=deactivate&user_id=<?= $user['id']; ?>">Désactiver</a>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>Aucun compte en attente de validation.</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
// Fermer la connexion à la base de données
$conn->close();
?>
