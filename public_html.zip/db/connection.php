<?php
$servername = "localhost";
$username = "mtpkkdef_admin";
$password = "qp:)qII@0wQ7&H&9wn";
$dbname = "mtpkkdef_bts_sio_stages";

// Créer une connexion
$conn = new mysqli($servername, $username, $password, $dbname);

