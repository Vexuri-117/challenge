<?php
// Inclure la connexion à la base de données
include 'connection.php';

function getAllOffers() {
    global $conn;
    $sql = "SELECT * FROM offers WHERE is_active = 1";
    return $conn->query($sql);
}

function getOfferDetails($offer_id) {
    global $conn;
    $sql = "SELECT * FROM offers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $offer_id);
    $stmt->execute();
    return $stmt->get_result();
}

function createUser($username, $email, $password, $role) {
    global $conn;
    $hashed_password = md5($password);
    $sql = "INSERT INTO users (username, password, email, role, status) VALUES (?, ?, ?, ?, 'pending')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $username, $hashed_password, $email, $role);
    return $stmt->execute();
}

function validateUser($user_id) {
    global $conn;
    $sql = "UPDATE users SET status = 'active' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    return $stmt->execute();
}
?>
