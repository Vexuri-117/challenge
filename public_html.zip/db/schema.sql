CREATE DATABASE IF NOT EXISTS bts_sio_stages;
USE bts_sio_stages;

-- Table des utilisateurs
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    role ENUM('student', 'organization', 'admin') NOT NULL,
    status ENUM('pending', 'active', 'inactive') DEFAULT 'pending'
);

-- Table des offres de stage
CREATE TABLE offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    organization_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    skills VARCHAR(255),
    location VARCHAR(255),
    period_start DATE,
    period_end DATE,
    nb_interns INT DEFAULT 1,
    category ENUM('Network', 'Development'),
    contact_email VARCHAR(255),
    contact_phone VARCHAR(15),
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (organization_id) REFERENCES users(id)
);

-- Table des candidatures
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    offer_id INT NOT NULL,
    application_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
    FOREIGN KEY (student_id) REFERENCES users(id),
    FOREIGN KEY (offer_id) REFERENCES offers(id)
);

-- Table des compétences
CREATE TABLE skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

-- Table de liaison entre offres et compétences
CREATE TABLE offer_skills (
    offer_id INT NOT NULL,
    skill_id INT NOT NULL,
    FOREIGN KEY (offer_id) REFERENCES offers(id),
    FOREIGN KEY (skill_id) REFERENCES skills(id)
);
