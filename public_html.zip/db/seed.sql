USE bts_sio_stages;

-- Insertion des compétences par défaut
INSERT INTO skills (name) VALUES 
('PHP'), 
('C#'), 
('JAVA'), 
('UML'), 
('Merise'), 
('GIT'), 
('SVN'), 
('MySQL');

-- Insertion d'un utilisateur administrateur
INSERT INTO users (username, password, email, role, status) VALUES 
('admin', MD5('password123'), 'admin@example.com', 'admin', 'active');
