<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STAGES HUB - Accueil</title>
    <link rel="stylesheet" href="assets/css/home.css">
</head>
<body>
    <!-- Section header -->
    <header>
    <div class="hero-background"></div>
    <div class="hero-text">
        <h1>Trouvez votre prochain stage</h1>
        <p>Des opportunités pour les étudiants du BTS SIO</p>
        <button id="explore-offers-btn" onclick="window.location.href='../students/index.php'">Explorer les offres</button>
        <div class="search-bar">
            <input type="text" placeholder="Rechercher un stage, une entreprise">
            <button>Rechercher</button>
        </div>
    </div>
    </header>


    <!-- Menu Burger -->
    <div class="burger">
    <div class="burger-icon"></div>
</div>

<div class="menu">
    <nav>
        <a href="index.php" class="active">Accueil</a>
        <a href="../auth/login.php">Connexion</a>
        <a href="../auth/register.php">Inscription</a>
        <a href="contact.php">Contact</a>
    </nav>
</div>


    <!-- Section populaire offres -->
    <section class="popular-offers">
        <h2>Offres populaires</h2>
        <div class="offer-grid">
            <!-- Exemple d'une carte d'offre -->
            <div class="offer-card">
                <img src="/assets/offer1.jpg" alt="Offre 1">
                <h3>Stage en développement web</h3>
                <p>Apprenez à créer des applications web modernes avec notre équipe dynamique.</p>
            </div>

            <!-- Autres cartes peuvent être ajoutées ici -->
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 STAGES HUB - Tous droits réservés</p>
        <p><a href="#">Mentions légales</a> | <a href="#">Politique de confidentialité</a></p>
    </footer>

    <script src="assets/js/home.js"></script>
    <script>
        function toggleMenu() {
        document.body.classList.toggle('open');
        }
    </script>

</body>
</html>
