<?php
// Fonction pour envoyer un email
function send_mail($to, $subject, $message, $headers = '') {
    // Utiliser la fonction mail() de PHP
    if (mail($to, $subject, $message, $headers)) {
        return true;  // Retourne true si l'email a été envoyé avec succès
    } else {
        return false; // Retourne false si l'email n'a pas pu être envoyé
    }
}

// Exemple d'utilisation pour réinitialiser un mot de passe
function send_password_reset_mail($user_email, $reset_link) {
    $subject = "Réinitialisation de votre mot de passe";
    $message = "
        <html>
        <head>
        <title>Réinitialisation de votre mot de passe</title>
        </head>
        <body>
        <p>Bonjour,</p>
        <p>Vous avez demandé une réinitialisation de votre mot de passe. Cliquez sur le lien ci-dessous pour le réinitialiser :</p>
        <a href='$reset_link'>Réinitialiser mon mot de passe</a>
        <p>Si vous n'avez pas demandé cette réinitialisation, ignorez cet email.</p>
        <p>Cordialement,</p>
        <p>L'équipe du lycée Frédéric Chopin</p>
        </body>
        </html>
    ";

    // Définir les en-têtes de l'email (important pour les emails HTML)
    $headers  = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: no-reply@lycee-chopin.com" . "\r\n";

    // Envoyer l'email
    return send_mail($user_email, $subject, $message, $headers);
}

// Exemple d'utilisation pour la validation d'une offre de stage
function send_stage_validation_mail($organization_email, $stage_title) {
    $subject = "Validation de votre offre de stage";
    $message = "
        <html>
        <head>
        <title>Validation de votre offre de stage</title>
        </head>
        <body>
        <p>Bonjour,</p>
        <p>Votre offre de stage intitulée '$stage_title' a été validée par notre équipe et est maintenant disponible pour les étudiants.</p>
        <p>Merci de faire partie de notre réseau de partenaires.</p>
        <p>Cordialement,</p>
        <p>L'équipe du lycée Frédéric Chopin</p>
        </body>
        </html>
    ";

    // Définir les en-têtes de l'email (important pour les emails HTML)
    $headers  = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: no-reply@lycee-chopin.com" . "\r\n";

    // Envoyer l'email
    return send_mail($organization_email, $subject, $message, $headers);
}

// Exemple d'utilisation pour envoyer une alerte de nouveau stage aux étudiants
function send_new_stage_alert($student_email, $stage_title, $stage_link) {
    $subject = "Nouvelle offre de stage disponible : $stage_title";
    $message = "
        <html>
        <head>
        <title>Nouvelle offre de stage</title>
        </head>
        <body>
        <p>Bonjour,</p>
        <p>Une nouvelle offre de stage a été ajoutée à la plateforme :</p>
        <p>Titre du stage : $stage_title</p>
        <p>Consultez les détails et postulez en cliquant sur le lien suivant :</p>
        <a href='$stage_link'>Voir l'offre de stage</a>
        <p>Bonne chance !</p>
        <p>Cordialement,</p>
        <p>L'équipe du lycée Frédéric Chopin</p>
        </body>
        </html>
    ";

    // Définir les en-têtes de l'email
    $headers  = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: no-reply@lycee-chopin.com" . "\r\n";

    // Envoyer l'email
    return send_mail($student_email, $subject, $message, $headers);
}
