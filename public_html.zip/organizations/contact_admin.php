<?php
session_start();
include '../db/connection.php';

// Vérifier si l'utilisateur est connecté et est une organisation
if ($_SESSION['role'] != 'organization') {
    header('Location: ../auth/login.php');
    exit();
}

// Envoyer un message à l'administrateur
if (isset($_POST['send_message'])) {
    $message = $_POST['message'];
    $organization_id = $_SESSION['user_id'];

    $sql = "INSERT INTO admin_messages (organization_id, message) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $organization_id, $message);

    if ($stmt->execute()) {
        echo "Message envoyé avec succès.";
    } else {
        echo "Erreur lors de l'envoi du message.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Contacter l'Administrateur</title>
</head>
<body>
    <h2>Contacter l'Administrateur</h2>

    <form action="contact_admin.php" method="POST">
        <label for="message">Votre message :</label>
        <textarea name="message" required></textarea>

        <button type="submit" name="send_message">Envoyer</button>
    </form>

    <a href="index.php">Retour au tableau de bord</a>
</body>
</html>
