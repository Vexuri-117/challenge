<form action="submit_offer.php" method="POST">
    <label for="title">Titre de l'offre</label>
    <input type="text" name="title" required>
    
    <label for="description">Description</label>
    <textarea name="description" required></textarea>

    <label for="skills">Compétences requises</label>
    <input type="text" id="skills-input">
    <button type="button" onclick="addSkill()">Ajouter</button>
    <ul id="skills-list"></ul>

    <script>
        function addSkill() {
            var skill = document.getElementById('skills-input').value;
            var list = document.getElementById('skills-list');
            var li = document.createElement('li');
            li.textContent = skill;
            list.appendChild(li);
        }
    </script>

    <button type="submit">Soumettre l'offre</button>
</form>
