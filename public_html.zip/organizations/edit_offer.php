<?php
session_start();
include '../db/connection.php';

// Vérifier si l'utilisateur est connecté et est une organisation
if ($_SESSION['role'] != 'organization') {
    header('Location: ../auth/login.php');
    exit();
}

// Vérifier si l'offre existe et appartient à l'organisation
if (isset($_POST['offer_id'])) {
    $offer_id = $_POST['offer_id'];
    $sql = "SELECT * FROM offers WHERE id = ? AND organization_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $offer_id, $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $offer = $result->fetch_assoc();

    if (!$offer) {
        echo "Offre introuvable.";
        exit();
    }
} else {
    header('Location: view_offers.php');
    exit();
}

// Mettre à jour l'offre
if (isset($_POST['update_offer'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $location = $_POST['location'];
    $keywords = $_POST['keywords'];

    $sql = "UPDATE offers SET title = ?, description = ?, category = ?, location = ?, keywords = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $title, $description, $category, $location, $keywords, $offer_id);

    if ($stmt->execute()) {
        echo "Offre mise à jour avec succès.";
    } else {
        echo "Erreur lors de la mise à jour.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Modifier une offre de stage</title>
</head>
<body>
    <h2>Modifier l'offre de stage</h2>

    <form action="edit_offer.php" method="POST">
        <input type="hidden" name="offer_id" value="<?php echo $offer['id']; ?>">
        
        <label for="title">Intitulé :</label>
        <input type="text" name="title" value="<?php echo $offer['title']; ?>" required>

        <label for="description">Description :</label>
        <textarea name="description" required><?php echo $offer['description']; ?></textarea>

        <label for="category">Catégorie :</label>
        <input type="text" name="category" value="<?php echo $offer['category']; ?>" required>

        <label for="location">Lieu :</label>
        <input type="text" name="location" value="<?php echo $offer['location']; ?>" required>

        <label for="keywords">Mots-clés :</label>
        <input type="text" name="keywords" value="<?php echo $offer['keywords']; ?>" required>

        <button type="submit" name="update_offer">Mettre à jour l'offre</button>
    </form>

    <a href="view_offers.php">Retour à la liste des offres</a>
</body>
</html>
