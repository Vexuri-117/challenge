<?php
session_start();
include '../db/connection.php';

// Vérifier si l'utilisateur est connecté et est une organisation
if ($_SESSION['role'] != 'organization') {
    header('Location: ../auth/login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Tableau de bord - Organisation</title>
</head>
<body>
    <h1>Bienvenue sur votre tableau de bord</h1>
    <p>Vous pouvez gérer vos offres de stage et contacter l'administrateur en cas de besoin.</p>

    <nav>
        <ul>
            <li><a href="create_offer.php">Créer une offre de stage</a></li>
            <li><a href="view_offers.php">Voir les offres publiées</a></li>
            <li><a href="contact_admin.php">Contacter l'administrateur</a></li>
            <li><a href="../auth/logout.php">Se déconnecter</a></li>
        </ul>
    </nav>
</body>
</html>
