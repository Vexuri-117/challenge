<?php
session_start();
include '../db/connection.php';

// Vérifier si l'utilisateur est connecté et est une organisation
if ($_SESSION['role'] != 'organization') {
    header('Location: ../auth/login.php');
    exit();
}

// Récupérer les offres publiées par l'organisation
$sql = "SELECT * FROM offers WHERE organization_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$offers = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Vos Offres de Stage</title>
</head>
<body>
    <h2>Vos Offres de Stage</h2>

    <table>
        <thead>
            <tr>
                <th>Intitulé</th>
                <th>Catégorie</th>
                <th>Lieu</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($offer = $offers->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $offer['title']; ?></td>
                <td><?php echo $offer['category']; ?></td>
                <td><?php echo $offer['location']; ?></td>
                <td>
                    <form action="edit_offer.php" method="POST" style="display: inline;">
                        <input type="hidden" name="offer_id" value="<?php echo $offer['id']; ?>">
                        <button type="submit">Modifier</button>
                    </form>
                    <form action="delete_offer.php" method="POST" style="display: inline;">
                        <input type="hidden" name="offer_id" value="<?php echo $offer['id']; ?>">
                        <button type="submit">Supprimer</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>

    <a href="create_offer.php">Créer une nouvelle offre</a>
</body>
</html>
