<?php
// Inclure la connexion à la base de données
include realpath(dirname(__FILE__) . '/../db/connection.php');

// Vérifier si l'ID de l'offre est passé via l'URL
if (isset($_GET['offer_id'])) {
    $offer_id = $_GET['offer_id'];

    // Vérifier si le formulaire a été soumis
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $student_id = $_POST['student_id']; // Récupérer l'ID de l'étudiant depuis la session ou le formulaire
        $motivation_letter = $_POST['motivation_letter'];

        // Insérer la candidature dans la base de données
        $query = "INSERT INTO applications (student_id, offer_id, motivation_letter) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('iis', $student_id, $offer_id, $motivation_letter);

        if ($stmt->execute()) {
            echo "Votre candidature a été envoyée avec succès.";
        } else {
            echo "Erreur lors de l'envoi de la candidature.";
        }
    }
} else {
    echo "Aucun ID d'offre spécifié.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Postuler pour un stage</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Postuler pour l'offre de stage</h1>

    <form action="apply.php?offer_id=<?= $offer_id; ?>" method="POST">
        <input type="hidden" name="student_id" value="1"> <!-- À remplacer par l'ID réel de l'étudiant via session -->
        <label for="motivation_letter">Lettre de motivation :</label><br>
        <textarea name="motivation_letter" id="motivation_letter" cols="30" rows="10" required></textarea><br>
        <input type="submit" value="Envoyer ma candidature">
    </form>
</body>
</html>

<?php
// Fermer la connexion à la base de données
$conn->close();
?>
