<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inclure la connexion à la base de données
include realpath(dirname(__FILE__) . '/../db/connection.php');

// Récupérer toutes les offres de stage actives depuis la base de données
$query = "SELECT * FROM offers WHERE status = 'active'";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offres de stage</title>
    <link rel="stylesheet" href="offers.css">
</head>
<body>
    
    <div class="burger">
    <div class="burger-icon"></div>
</div>

<div class="menu">
    <nav>
        <a href="index.php" class="active">Accueil</a>
        <a href="../auth/login.php">Connexion</a>
        <a href="../auth/register.php">Inscription</a>
        <a href="contact.php">Contact</a>
    </nav>
</div>

    <div class="offers-container">
        <h1>Liste des offres de stage</h1>
        
        <!-- Formulaire de recherche -->
        <div class="search-form">
            <input type="text" id="search-input" placeholder="Rechercher un stage par mots-clés">
            <button id="search-btn">Rechercher</button>
        </div>

        <!-- Liste des offres -->
        <ul class="offers-list">
            <li class="offer-item">
                <h2>CAPGEMINI</h2>
                <p><strong>Compétences :</strong> Développement Web, HTML, CSS</p>
                <p><strong>Nombre de stagiaires :</strong> 2</p>
                <a href="offer_details.php?offer_id=1">Voir les détails</a>
            </li>
            <!-- Plus d'offres ici -->
        </ul>
    </div>
    
    <script src="offers.js"></script>
    <script src="assets/js/home.js"></script>
    <script>
        function toggleMenu() {
        document.body.classList.toggle('open');
        }
    </script>
</body>
</html>


<?php
// Fermer la connexion à la base de données
$conn->close();
?>
