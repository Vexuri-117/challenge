<?php
// Inclure la connexion à la base de données
include realpath(dirname(__FILE__) . '/../db/connection.php');

// Vérifier si l'ID de l'offre est passé via l'URL
if (isset($_GET['offer_id'])) {
    $offer_id = $_GET['offer_id'];

    // Récupérer les détails de l'offre
    $query = "SELECT * FROM offers WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $offer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $offer = $result->fetch_assoc();
    } else {
        echo "Offre non trouvée.";
        exit;
    }
} else {
    echo "Aucun ID d'offre spécifié.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Détails de l'offre</title>
    <link rel="stylesheet" href="offer_details.css">
</head>
<body>
    
    <div class="burger">
    <div class="burger-icon"></div>
</div>

<div class="menu">
    <nav>
        <a href="index.php" class="active">Accueil</a>
        <a href="../auth/login.php">Connexion</a>
        <a href="../auth/register.php">Inscription</a>
        <a href="contact.php">Contact</a>
    </nav>
</div>

    <div class="offer-details-container">
        <h1>Détails de l'offre</h1>

        <!-- Informations générales -->
        <p><strong>Nom de l'organisation :</strong> CAPGEMINI</p>
        <p><strong>Compétences requises :</strong> Développement Web, PHP, SQL</p>
        <p><strong>Nombre de stagiaires :</strong> 2</p>
        <p><strong>Description :</strong> Description complète de l'offre de stage.</p>

        <!-- Tableau des informations supplémentaires -->
        <table class="offer-info-table">
            <tr>
                <th>Durée</th>
                <td>3 mois</td>
            </tr>
            <tr>
                <th>Localisation</th>
                <td>Paris, France</td>
            </tr>
            <tr>
                <th>Rémunération</th>
                <td>600€/mois</td>
            </tr>
        </table>

        <!-- Bouton retour -->
        <a href="../students/index.php" class="back-btn">Retour aux offres</a>
    </div>
    
    <script src="assets/js/home.js"></script>
    <script>
        function toggleMenu() {
        document.body.classList.toggle('open');
        }
    </script>
</body>
</html>


<?php
// Fermer la connexion à la base de données
$conn->close();
?>
