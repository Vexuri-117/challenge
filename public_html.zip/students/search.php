<?php
// Inclure la connexion à la base de données
include('../db/connection.php');

// Initialiser les variables de recherche
$keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '';
$location = isset($_GET['location']) ? $_GET['location'] : '';
$skills = isset($_GET['skills']) ? $_GET['skills'] : '';

// Construire la requête SQL avec les filtres
$query = "SELECT * FROM offers WHERE status = 'active'";

if (!empty($keyword)) {
    $query .= " AND (organization_name LIKE '%$keyword%' OR description LIKE '%$keyword%')";
}
if (!empty($location)) {
    $query .= " AND location LIKE '%$location%'";
}
if (!empty($skills)) {
    $query .= " AND skills LIKE '%$skills%'";
}

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche de stages</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <h1>Recherche de stages</h1>

    <form action="search.php" method="GET">
        <label for="keyword">Mot-clé :</label>
        <input type="text" id="keyword" name="keyword" value="<?= $keyword; ?>"><br>

        <label for="location">Lieu :</label>
        <input type="text" id="location" name="location" value="<?= $location; ?>"><br>

        <label for="skills">Compétences :</label>
        <input type="text" id="skills" name="skills" value="<?= $skills; ?>"><br>

        <input type="submit" value="Rechercher">
    </form>

    <div class="offers-list">
        <?php if ($result->num_rows > 0): ?>
            <ul>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <li>
                        <h2><?= $row['organization_name']; ?></h2>
                        <p><strong>Compétences :</strong> <?= $row['skills']; ?></p>
                        <p><strong>Lieu :</strong> <?= $row['location']; ?></p>
                        <a href="offer_details.php?offer_id=<?= $row['id']; ?>">Voir les détails</a>
                    </li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>Aucune offre de stage trouvée.</p>
        <?php endif; ?>
    </div>
    
    <footer>
        <p>&copy; 2024 STAGES HUB - Tous droits réservés</p>
        <p><a href="#">Mentions légales</a> | <a href="#">Politique de confidentialité</a></p>
    </footer>

    <script src="assets/js/home.js"></script>
    <script>
        function toggleMenu() {
        document.body.classList.toggle('open');
        }
    </script>
</body>
</html>

<?php
// Fermer la connexion à la base de données
$conn->close();
?>
