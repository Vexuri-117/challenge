<?php
include '../db/connection.php';
session_start();
if ($_SESSION['role'] != 'admin') {
    header("Location: ../auth/login.php");
    exit();
}

// Récupération des offres, comptes et candidatures pour les afficher
$query_offers = "SELECT * FROM offers";
$result_offers = mysqli_query($conn, $query_offers);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Backoffice - Gestion des stages</title>
</head>
<body>
    <header>
        <h1>Backoffice - Gestion des stages</h1>
    </header>
    <main>
        <section>
            <h2>Liste des offres de stage</h2>
            <table>
                <thead>
                    <tr>
                        <th>Titre</th>
                        <th>Organisation</th>
                        <th>Lieu</th>
                        <th>Période</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result_offers)) { ?>
                    <tr>
                        <td><?= $row['title'] ?></td>
                        <td><?= $row['organization_id'] ?></td>
                        <td><?= $row['location'] ?></td>
                        <td><?= $row['period_start'] ?> - <?= $row['period_end'] ?></td>
                        <td>
                            <a href="manage_offers.php?id=<?= $row['id'] ?>">Modifier</a> |
                            <a href="delete_offer.php?id=<?= $row['id'] ?>">Supprimer</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>