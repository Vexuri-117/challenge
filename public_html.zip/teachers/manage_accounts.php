<?php
include '../db/connection.php';
session_start();

// Vérifier si l'utilisateur est admin
if ($_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Validation ou désactivation d'un compte utilisateur
if (isset($_POST['action']) && isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];
    $action = $_POST['action'];

    if ($action == 'validate') {
        $sql = "UPDATE users SET status = 'active' WHERE id = ?";
    } elseif ($action == 'deactivate') {
        $sql = "UPDATE users SET status = 'inactive' WHERE id = ?";
    } elseif ($action == 'delete') {
        $sql = "DELETE FROM users WHERE id = ?";
    }
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        echo "Action effectuée avec succès.";
    }
}

// Récupérer les utilisateurs
$sql = "SELECT * FROM users";
$users = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Gestion des Comptes Utilisateurs</title>
</head>
<body>
    <h2>Gestion des Comptes Utilisateurs</h2>
    
    <table>
        <thead>
            <tr>
                <th>Nom d'utilisateur</th>
                <th>Email</th>
                <th>Rôle</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($user = $users->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $user['username']; ?></td>
                <td><?php echo $user['email']; ?></td>
                <td><?php echo $user['role']; ?></td>
                <td><?php echo $user['status']; ?></td>
                <td>
                    <?php if ($user['status'] == 'pending') { ?>
                        <form action="manage_accounts.php" method="POST" style="display: inline;">
                            <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                            <button type="submit" name="action" value="validate">Valider</button>
                        </form>
                    <?php } ?>
                    <form action="manage_accounts.php" method="POST" style="display: inline;">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <button type="submit" name="action" value="deactivate">Désactiver</button>
                    </form>
                    <form action="manage_accounts.php" method="POST" style="display: inline;">
                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                        <button type="submit" name="action" value="delete">Supprimer</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
