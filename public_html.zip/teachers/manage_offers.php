<?php
include '../db/connection.php';
session_start();

// Vérifier si l'utilisateur est admin
if ($_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Suppression d'une offre de stage
if (isset($_POST['delete_offer'])) {
    $offer_id = $_POST['offer_id'];
    $sql = "DELETE FROM offers WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $offer_id);
    if ($stmt->execute()) {
        echo "Offre supprimée avec succès.";
    }
}

// Récupérer les offres existantes
$sql = "SELECT * FROM offers";
$offers = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Gestion des Offres de Stage</title>
</head>
<body>
    <h2>Gestion des Offres de Stage</h2>
    
    <table>
        <thead>
            <tr>
                <th>Organisation</th>
                <th>Intitulé</th>
                <th>Catégorie</th>
                <th>Période</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($offer = $offers->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $offer['organization_id']; ?></td>
                <td><?php echo $offer['title']; ?></td>
                <td><?php echo $offer['category']; ?></td>
                <td><?php echo $offer['period_start'] . " - " . $offer['period_end']; ?></td>
                <td>
                    <form action="edit_offer.php" method="POST" style="display: inline;">
                        <input type="hidden" name="offer_id" value="<?php echo $offer['id']; ?>">
                        <button type="submit">Modifier</button>
                    </form>
                    <form action="manage_offers.php" method="POST" style="display: inline;">
                        <input type="hidden" name="offer_id" value="<?php echo $offer['id']; ?>">
                        <button type="submit" name="delete_offer">Supprimer</button>
                    </form>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
    
    <a href="add_offer.php">Ajouter une nouvelle offre</a>
</body>
</html>
