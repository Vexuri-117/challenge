<?php
include '../db/connection.php';
session_start();

// Vérifier si l'utilisateur est admin
if ($_SESSION['role'] != 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Ajouter une période de stage
if (isset($_POST['add_period'])) {
    $class = $_POST['class'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    $sql = "INSERT INTO stages (class, period_start, period_end) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $class, $start_date, $end_date);
    if ($stmt->execute()) {
        echo "Période de stage ajoutée avec succès.";
    }
}

// Récupérer les périodes de stage existantes
$sql = "SELECT * FROM stages";
$stages = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="../assets/css/style.css">
    <title>Gestion des Stages</title>
</head>
<body>
    <h2>Définition des périodes de stage</h2>
    
    <form action="manage_stage.php" method="POST">
        <label for="class">Classe :</label>
        <input type="text" name="class" required>
        
        <label for="start_date">Date de début :</label>
        <input type="date" name="start_date" required>
        
        <label for="end_date">Date de fin :</label>
        <input type="date" name="end_date" required>
        
        <button type="submit" name="add_period">Ajouter la période</button>
    </form>
    
    <h3>Périodes de stage existantes</h3>
    
    <table>
        <thead>
            <tr>
                <th>Classe</th>
                <th>Date de début</th>
                <th>Date de fin</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($stage = $stages->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $stage['class']; ?></td>
                <td><?php echo $stage['period_start']; ?></td>
                <td><?php echo $stage['period_end']; ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>
